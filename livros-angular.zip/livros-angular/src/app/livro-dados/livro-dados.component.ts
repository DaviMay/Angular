
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ControleLivrosService } from '../services/controle-livros.service';
import { ControleEditorasService } from '../services/controle-editoras.service';
import { Editora } from '../models/editora';
import { Livro } from '../models/livro';

@Component({
  selector: 'app-livro-dados',
  templateUrl: './livro-dados.component.html'
})
export class LivroDadosComponent {
  editoras: Array<Editora> = [];
  livro: Livro = new Livro(0, 1, '', '', []);
  autoresTexto: string = '';

  constructor(private servLivros: ControleLivrosService, private servEditoras: ControleEditorasService, private router: Router) {}

  ngOnInit() {
    this.editoras = this.servEditoras.getEditoras();
    if (this.editoras.length) {
      this.livro.codEditora = this.editoras[0].codEditora;
    }
  }

  incluir(): void {
    // Converter autoresTexto (1 autor por linha) para array
    this.livro.autores = this.autoresTexto.split('
')
      .map(a => a.trim())
      .filter(a => !!a);

    this.servLivros.incluir(this.livro);
    this.router.navigateByUrl('/lista');
  }
}
