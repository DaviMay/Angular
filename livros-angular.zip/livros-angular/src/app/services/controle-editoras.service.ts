
import { Injectable } from '@angular/core';
import { Editora } from '../models/editora';

@Injectable()
export class ControleEditorasService {
  private editoras: Array<Editora> = [
    new Editora(1, 'Addison Wesley'),
    new Editora(2, 'Alta Books'),
    new Editora(3, 'Pearson')
  ];

  getEditoras(): Array<Editora> {
    return this.editoras;
  }

  getNomeEditora(codEditora: number): string {
    const e = this.editoras.find(ed => ed.codEditora === codEditora);
    return e ? e.nome : '—';
  }
}
