
import { Injectable } from '@angular/core';
import { Livro } from '../models/livro';

@Injectable()
export class ControleLivrosService {
  private livros: Array<Livro> = [
    new Livro(1, 2, 'Use a Cabeça: Java', 'Uma experiência completa de aprendizado em OO e Java.', ['Bert Bates', 'Kathy Sierra']),
    new Livro(2, 3, 'Java, Como Programar', 'Milhões de alunos aprendem programação com os livros Deitel.', ['Paul Deitel', 'Harvey Deitel'])
  ];

  obterLivros(): Array<Livro> {
    return this.livros;
  }

  incluir(livro: Livro): void {
    const maiorCodigo = this.livros.reduce((max, l) => Math.max(max, l.codigo), 0);
    livro.codigo = maiorCodigo + 1;
    this.livros.push(livro);
  }

  excluir(codigo: number): void {
    const idx = this.livros.findIndex(l => l.codigo === codigo);
    if (idx > -1) {
      this.livros.splice(idx, 1);
    }
  }
}
