
export class Editora {
  constructor(
    public codEditora: number,
    public nome: string
  ) {}
}
