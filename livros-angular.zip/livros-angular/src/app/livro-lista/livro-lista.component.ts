
import { Component } from '@angular/core';
import { ControleLivrosService } from '../services/controle-livros.service';
import { ControleEditorasService } from '../services/controle-editoras.service';
import { Livro } from '../models/livro';

@Component({
  selector: 'app-livro-lista',
  templateUrl: './livro-lista.component.html'
})
export class LivroListaComponent {
  livros: Array<Livro> = [];

  constructor(private servLivros: ControleLivrosService, private servEditoras: ControleEditorasService) {}

  ngOnInit() {
    this.obterLivros();
  }

  obterLivros(): void {
    this.livros = this.servLivros.obterLivros();
  }

  excluir(codigo: number): void {
    this.servLivros.excluir(codigo);
    this.obterLivros();
  }

  getNomeEditora(codEditora: number): string {
    return this.servEditoras.getNomeEditora(codEditora);
  }
}
